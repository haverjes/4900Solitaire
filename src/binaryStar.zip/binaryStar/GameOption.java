package binaryStar;

public class GameOption 
{
	public String name;
	public String file;
	
	public GameOption(String sName, String sFile)
	{
		name = sName;
		file = sFile;
	}

}
