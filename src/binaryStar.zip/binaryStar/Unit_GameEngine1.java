package binaryStar;

import org.junit.jupiter.api.Test;

class Unit_GameEngine1 {

	@Test
	final void test() {
		


		BinaryStar.XMLFile = "GameUnitTest_Move1.xml";

		
		BinaryStar.main(null);

	}

}
